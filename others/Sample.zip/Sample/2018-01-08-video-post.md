---
title: Video Example!
date: 2017-04-01
---

这是一个视频例子


<!-- 视频  -->
你可以参考这个 [地址](https://gohugo.io/content-management/shortcodes/#youtube)

<!--more-->

{{< youtube BNRIuaxd1YQ >}}


代码如下：

```
{{</* youtube BNRIuaxd1YQ */>}}

or 

{{</* youtube id="BNRIuaxd1YQ" autoplay="true" */>}}

```
